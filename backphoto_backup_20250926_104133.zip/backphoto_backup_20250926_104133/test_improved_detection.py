#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
改进的后脑勺检测测试程序
- 不拍正脸，只拍后脑勺
- 拍照时播放声音提示
- 实时显示检测状态
"""

import sys
import os
from back_detector import BackDetector

def test_improved_detection():
    """测试改进的后脑勺检测功能"""
    print("=" * 60)
    print("           改进的后脑勺检测测试")
    print("=" * 60)
    print("功能特点：")
    print("✅ 只拍后脑勺，不拍正脸")
    print("✅ 拍照时播放声音提示")
    print("✅ 实时显示检测状态")
    print("=" * 60)
    
    detector = BackDetector()
    
    # 检查摄像头
    print("\n1. 检查摄像头...")
    if not detector.start_camera():
        print("❌ 摄像头启动失败")
        print("请检查：")
        print("- 摄像头是否被其他程序占用")
        print("- 摄像头权限是否已开启")
        print("- 摄像头设备是否正常")
        return False
    
    print("✅ 摄像头启动成功")
    
    # 开始检测
    print("\n2. 开始后脑勺检测...")
    print("📋 使用说明：")
    print("   - 将后脑勺对准摄像头")
    print("   - 系统会检测正脸，检测到正脸时不拍照")
    print("   - 只有检测到后脑勺时才会拍照")
    print("   - 拍照时会播放声音提示")
    print("   - 按ESC键停止检测")
    print("\n🎯 开始检测...")
    
    photo_count = 0
    
    def photo_callback(photo_path):
        nonlocal photo_count
        photo_count += 1
        print(f"📸 第 {photo_count} 张后脑勺照片已拍摄: {photo_path}")
    
    try:
        detector.start_detection(photo_callback)
        print(f"\n🎉 检测完成！")
        print(f"📊 统计结果：")
        print(f"   - 共拍摄了 {photo_count} 张后脑勺照片")
        print(f"   - 系统成功避免了拍摄正脸")
        print(f"   - 所有照片都保存在 photos/ 目录中")
        return True
    except Exception as e:
        print(f"检测过程中出错: {e}")
        return False
    finally:
        detector.stop_detection()

def main():
    """主函数"""
    print("改进的后脑勺检测拍照系统 - 测试程序")
    
    if test_improved_detection():
        print("\n🎉 测试成功！")
        print("系统已准备就绪，可以开始使用改进的后脑勺检测功能")
        print("\n📝 主要改进：")
        print("1. ✅ 智能正脸检测 - 检测到正脸时不拍照")
        print("2. ✅ 声音提示 - 拍照时播放提示音")
        print("3. ✅ 视觉反馈 - 实时显示检测状态")
        print("4. ✅ 冷却机制 - 检测到正脸后3秒内不拍照")
    else:
        print("\n❌ 测试失败")
        print("请检查系统配置和摄像头权限")

if __name__ == "__main__":
    main()
